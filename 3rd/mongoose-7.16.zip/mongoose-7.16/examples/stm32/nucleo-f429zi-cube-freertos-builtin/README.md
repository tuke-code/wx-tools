See [Wizard](https://mongoose.ws/wizard/#/output?board=f429&ide=CubeIDE&rtos=FreeRTOS&file=README.md)
