# RP2040 + W5500 Ethernet chip

- See detailed tutorial (including hardware connections) at https://mongoose.ws/tutorials/rp2040/pico-w5500/
