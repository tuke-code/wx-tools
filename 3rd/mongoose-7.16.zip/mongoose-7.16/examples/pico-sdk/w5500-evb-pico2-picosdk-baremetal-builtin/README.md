# RP2350 + W5500 Ethernet chip

- See [detailed tutorial](https://mongoose.ws/tutorials/rp2040/pico-w5500/) (including hardware connections)
