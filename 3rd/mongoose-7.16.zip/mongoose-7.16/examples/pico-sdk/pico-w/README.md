See detailed tutorial at https://mongoose.ws/tutorials/rp2040/pico-w/
