See [Wizard](https://mongoose.ws/wizard/#/output?board=rt1060&ide=GCC+make&rtos=baremetal&file=README.md)
