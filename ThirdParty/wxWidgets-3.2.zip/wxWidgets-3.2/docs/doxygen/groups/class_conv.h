/////////////////////////////////////////////////////////////////////////////
// Name:        class_conv.h
// Purpose:     Conversion classes group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_conv Text Conversion
@ingroup group_class

These are the classes used for conversions between different text encodings.

*/

