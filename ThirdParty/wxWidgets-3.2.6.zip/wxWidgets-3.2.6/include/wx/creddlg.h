///////////////////////////////////////////////////////////////////////////////
// Name:        wx/creddlg.h
// Purpose:     wxCredentialEntryDialog interface
// Author:      Tobias Taschner
// Created:     2018-10-23
// Copyright:   (c) 2018 wxWidgets development team
// Licence:     wxWindows licence
///////////////////////////////////////////////////////////////////////////////

#ifndef _WX_CREDDLG_H_BASE
#define _WX_CREDDLG_H_BASE

#include "wx/generic/creddlgg.h"

#endif // _WX_CREDDLG_H_BASE
